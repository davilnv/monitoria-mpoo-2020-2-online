package model;

public class FuncionarioException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FuncionarioException(String erro) {
		super(erro);
	}
}
