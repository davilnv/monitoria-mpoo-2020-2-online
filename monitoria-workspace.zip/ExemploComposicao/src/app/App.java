package app;

public class App {
	public static void main(String[] args) {
		// EXEMPLO DE COMPOSI��O
		/*
		// Uma parte n�o pode existir sem o todo;
		// Todo ele pode existir seem a parte;
		
		Carro carro = new Carro("Fiat", 1.0);
		Pneu pneu1 = new Pneu(18, carro);
//		carro.getPneus().add(pneu1); // Insere duas vezes a mesma inst�ncia
		
		System.out.println(carro);
		*/
		
	}
}
