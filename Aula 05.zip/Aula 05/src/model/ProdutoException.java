package model;

public class ProdutoException extends Exception{

	public ProdutoException(String msgErro) {
		super(msgErro);
	}
	
}
