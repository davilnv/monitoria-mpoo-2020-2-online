package br.com.mpoo.model;

public class Cachorro extends Animal {

	public Cachorro(Proprietario proprietario) {
		super(proprietario);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String informacaoAlimentacao() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
