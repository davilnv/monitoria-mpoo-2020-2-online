package br.com.mpoo.model;

public interface Alimentacao {
	
	public String informacaoAlimentacao();
	
}
