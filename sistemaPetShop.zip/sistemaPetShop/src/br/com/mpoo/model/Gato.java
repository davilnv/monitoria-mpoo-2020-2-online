package br.com.mpoo.model;

public class Gato extends Animal{

	public Gato(Proprietario proprietario) {
		super(proprietario);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String informacaoAlimentacao() {
		// TODO Auto-generated method stub
		return null;
	}

}
