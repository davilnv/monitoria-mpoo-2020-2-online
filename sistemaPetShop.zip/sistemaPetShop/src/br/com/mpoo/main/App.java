package br.com.mpoo.main;

public class App {
	public static void main(String[] args) {
		
	}
}
